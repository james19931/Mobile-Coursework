package com.example.james.mobilecoursework;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;

/**
 * Created by James on 11/22/2014.
 */
// Dialogue used to show what the app is about.
public class aboutDialogue extends DialogFragment
{
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState)
    {
        AlertDialog.Builder mcAboutDialog = new AlertDialog.Builder(getActivity());
        mcAboutDialog.setMessage("Ths is a disney app it will give you disney news, Give you information on characters and show you disney world on google maps")
                .setPositiveButton("Ok",new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int id)
                    {

                    }
                });
        mcAboutDialog.setTitle("About");
        return mcAboutDialog.create();
    }
}