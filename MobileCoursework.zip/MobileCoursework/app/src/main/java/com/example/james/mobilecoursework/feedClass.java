package com.example.james.mobilecoursework;

import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

/**
 * Created by James on 11/22/2014.
 */
//used to read in the feed from the disney news site
public class feedClass
{
    // Method to handle the reading of the data from the RSS stream
    String getNewsFeed(String urlString)throws IOException
    {
        Log.e("n", "Entered method");
        String result = "";
        InputStream anInStream = null;
        int response = -1;
        URL url = new URL(urlString);
        URLConnection conn = url.openConnection();

        // Check that the connection can be opened
        if (!(conn instanceof HttpURLConnection))
            throw new IOException("Not an HTTP connection");
        try
        {
            Log.e("n", "entered try block feed");
            // Open connection
            HttpURLConnection httpConn = (HttpURLConnection) conn;
            httpConn.setAllowUserInteraction(false);
            httpConn.setInstanceFollowRedirects(true);
            httpConn.setRequestMethod("GET");
            httpConn.connect();
            response = httpConn.getResponseCode();
            // Check that connection is Ok
            if (response == HttpURLConnection.HTTP_OK)
            {
                Log.e("n", "in if statement");
                // Connection is Ok so open a reader
                anInStream = httpConn.getInputStream();
                InputStreamReader in= new InputStreamReader(anInStream);
                BufferedReader bin= new BufferedReader(in);

                // Read in the data from the RSS stream
                String line = new String();
                while (( (line = bin.readLine())) != null)
                {
                    Log.e("n", "in while");
                    result = result + line;
                }
            }
        }
        catch (Exception ex)
        {
            throw new IOException("Error connecting");
        }
        // Return result as a string for further processing
        Log.e("n", "returned result");
        return result;

    } // End of getRoadworks
}
