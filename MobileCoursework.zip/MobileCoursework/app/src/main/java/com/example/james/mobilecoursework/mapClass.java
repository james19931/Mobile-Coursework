package com.example.james.mobilecoursework;

/**
 * Created by James on 11/27/2014.
 */
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class mapClass extends Activity implements View.OnClickListener
{
    public GoogleMap map;
    Button btnParis;
    Button btnDisneyWorld;
    Button btnViewDisneyWorld;
    Button btnViewParis;

    // set up coordinates
    final LatLng paris = new LatLng(48.872234,2.775808);
    final LatLng disneyWorld = new LatLng(28.417850,-81.581235);


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.map);
        initialise(); // set up gui
    }

    public void initialise()
    {
        BitmapDescriptor icon = BitmapDescriptorFactory.fromResource(R.drawable.mickey46); // set up an icon
        map = ((MapFragment) getFragmentManager().findFragmentById(R.id.map)).getMap(); // set up map

        // set up custom markers
        map.addMarker(new MarkerOptions().position(paris).title("Find me here")).setIcon(icon);
        map.addMarker(new MarkerOptions().position(disneyWorld).title("Find me here")).setIcon(icon);


        // set up buttons and add on click listeners
        btnParis =(Button)findViewById(R.id.disneyParis);
        btnParis.setOnClickListener(this);

        btnDisneyWorld =(Button)findViewById(R.id.disneyWorld);
        btnDisneyWorld.setOnClickListener(this);

        btnViewDisneyWorld = (Button)findViewById(R.id.viewDisneyWorld);
        btnViewDisneyWorld.setOnClickListener(this);

        btnViewParis = (Button)findViewById(R.id.viewParis);
        btnViewParis.setOnClickListener(this);
    }

    @Override
    public void onClick(View v)
    {

        // sets the view to satellite
        if(v==btnViewParis)
        {
            map.setMapType(GoogleMap.MAP_TYPE_SATELLITE); // set map view to satellite
            CameraUpdate update = CameraUpdateFactory.newLatLngZoom(paris,18); // set the zoom level
            map.animateCamera(update);
        }

        // sets the map to paris
        if(v==btnParis)
        {
            CameraUpdate update = CameraUpdateFactory.newLatLngZoom(paris,12);
            map.animateCamera(update);
        }

        // sets the map to disney world
        if(v==btnDisneyWorld)
        {
            CameraUpdate update = CameraUpdateFactory.newLatLngZoom(disneyWorld,12);
            map.animateCamera(update);
        }

        // sets the view to satellite
        if(v==btnViewDisneyWorld)
        {
            map.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
            CameraUpdate update = CameraUpdateFactory.newLatLngZoom(disneyWorld,16);
            map.animateCamera(update);
        }
    }
}

