package com.example.james.mobilecoursework;


/**
 * Created by James on 11/25/2014.
 */

// This class is used in order to store details read in from the database it contains the details to be stored as its variables and getter and setters for them
public class characterClass
{
    int id;
    String charName;
    String charDescription;
    String imageName;


    public void setImageName(String myImage) {
        this.imageName = myImage;
    }

    public String getImageName() {
        return imageName;
    }

    public void setId(int myId) {
        this.id = myId;
    }

    public int getId() {
        return id;
    }

    public void setCharName(String myCharName) {
        this.charName = myCharName;
    }

    public String getCharName() {
        return charName;
    }

    public void setCharDescription(String myCharDescription) {
        this.charDescription = myCharDescription;
    }

    public String getCharDescription()
    {
        return charDescription;
    }
}


