package com.example.james.mobilecoursework;

import android.app.DialogFragment;
import android.app.FragmentManager;
import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import java.util.LinkedList;
import java.util.List;

// this class will be used to display disney news headlines. This will be done by reading in an RSS feed and parsing the appropriate data
public class MainActivity extends ActionBarActivity
{
    feedClass myFeed = new feedClass(); // set up feed object to read in data
    parserClass myParser = new parserClass(); // set up parse object to parse xml

    FragmentManager fmAboutDialogue;
    LinkedList<newsItem> alist;
    ListView newsList;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        setTitle("News Feed");
        fmAboutDialogue = this.getFragmentManager();
        initialise();
        readRSS();
    }

    public void initialise()
    {
        // set up list view
        newsList = (ListView)findViewById(R.id.newsList);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.mc_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // provides the functionality to the menu which calls activities based on the users choice. This is done through use of a switch statement
        switch(item.getItemId())
        {
            case R.id.about:
                // set up and display the dialog
                DialogFragment mcAboutDlg = new aboutDialogue();
                mcAboutDlg.show(fmAboutDialogue, "About_Dlg");
                return true;
            case R.id.news:
                Log.e("n", "picked news");
                readRSS(); // call rss method in order to retrieve news information from disney news site
                return true;
            case R.id.characters:
                // set up intent and call characters activity
                Intent characters = new Intent(this,characterDisplay.class);
                this.startActivity(characters);
                return true;
            case R.id.preferences:
                // set up intent and call the preferences activity
                Intent pref = new Intent(this,preferenceClass.class);
                this.startActivity(pref);
                return true;
            case R.id.map:
                // set up intent and call google maps activity
                Intent map = new Intent(this,mapClass.class);
                this.startActivity(map);
                return true;
            case R.id.quit:
                // close application
                finish();
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void readRSS()
    {
        // start loading dialog
        final ProgressDialog myDialog = ProgressDialog.show(MainActivity.this, "Loading....", "Please Wait");
        // start thread
        new Thread(new Runnable()
        {
            public void run()
            {
                // enter try block to read in and parse data
                try
                {
                    // read in rss feed and store it in a string
                    String url = "http://www.wdwinfo.com/news/rss.xml";
                    String results = myFeed.getNewsFeed(url);

                    // store parsed data in a linked list
                    alist =  myParser.parseData(results);
                    Log.e("n",results);
                }catch (Exception e) // catch section
                {
                    Toast.makeText(MainActivity.this, "Unable to retrieve data", Toast.LENGTH_SHORT).show(); // display message to user should something go wrong
                    e.printStackTrace();
                }
                newsList.post(new Runnable() // update UI thread through use of a post new runnable
                {
                    public void run()
                    {
                        populateListView(alist); //display listview
                        myDialog.dismiss(); // close loading dialog
                    }
                });
            }
        }).start();
    }

    private void populateListView(List<newsItem> alist)
    {
        // set up an adapter and put objects in the list view
        ArrayAdapter<newsItem> arrayAdapter = new ArrayAdapter<newsItem>(this, android.R.layout.simple_list_item_1, alist);
        newsList.setAdapter(arrayAdapter);
    }
}
