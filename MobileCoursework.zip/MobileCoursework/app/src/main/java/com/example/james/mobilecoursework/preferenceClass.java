package com.example.james.mobilecoursework;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

/**
 * Created by James on 11/25/2014.
 */

// This class is used in order to save user preferences on the next disney film they would like to see.
public class preferenceClass extends ActionBarActivity implements View.OnClickListener
{
    Button btnSave;
    Button btnLoad;
    EditText namePref;
    EditText filmPref;
    final String filename = "mySharedPreferences";

    SharedPreferences userPreference;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.preferences);
        setTitle("Profile");
        initialise();
        userPreference =  getSharedPreferences(filename,0);

    }

    public void initialise()
    {
        // initalise components of ui
        btnSave = (Button)findViewById(R.id.btnSave);
        btnLoad = (Button)findViewById(R.id.btnLoad);
        namePref = (EditText)findViewById(R.id.namePref);
        filmPref = (EditText)findViewById(R.id.filmPref);

        // set on click listeners
        btnSave.setOnClickListener(this);
        btnLoad.setOnClickListener(this);
    }

    public void savePreferences(String name, String film)
    {
        // save preferences using a key and a value
        SharedPreferences.Editor userEditor = userPreference.edit();
        userEditor.putString("name",name);
        userEditor.putString("film",film);
        userEditor.commit(); // save changes
    }

    public void loadPreferences()
    {
        // loads user preferences and stores displays them through text fields
        userPreference =  getSharedPreferences(filename,0);

        // stores the user preferences in strings using the key as a paramter for getString. It also takes a string to act as a default value should something go wrong.
        String name = userPreference.getString("name","could not load");
        String film = userPreference.getString("film","could not load");

        // set text fields
        namePref.setText(name);
        filmPref.setText(film);
    }

    @Override
    public void onClick(View v)
    {
        // if user clicks save button
        if(v== btnSave)
        {
            // store user entry from edit text into a string
            String name = namePref.getText().toString();
            String film = filmPref.getText().toString();

            // call save preferences method passing in the data from the edit texts
            savePreferences(name,film);
        }

        // if user clicks load button
        if(v==btnLoad)
        {
            // call load preferences method
            loadPreferences();
        }
    }
}
