package com.example.james.mobilecoursework;

/**
 * Created by James on 11/22/2014.
 */
// this class is used to store the data collected from the news feed. it consists of the data to be stored and getter and setters
public class newsItem
{
    String title;
    String pubDate;
    String description;

    public newsItem()
    {
        title = "";
        description = "";
        pubDate = "";
    }

    public newsItem(String aTitle,String aDescription,String aPubDate)
    {
        title = aTitle;
        description = aDescription;
        pubDate = aPubDate;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String aTitle)
    {
        title = aTitle;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String aDescription)
    {
        description = aDescription;
    }

    public String getPubDate()
    {
        return pubDate;
    }

    public void setPubDate(String aPubDate)
    {
        pubDate = aPubDate;
    }

    // this allows the data to be displayed in the list view
    public String toString()
    {
        String temp;

        temp = title + "\n ";

        return temp;
    }
}
