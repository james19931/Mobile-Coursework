package com.example.james.mobilecoursework;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import java.io.IOException;


/**
 * Created by James on 11/22/2014.
 */

// this class will be used to show information on the disney characters. this information will be read in from a database
public class characterDisplay extends ActionBarActivity implements  AdapterView.OnItemSelectedListener
{

    TextView charName;
    TextView charDescription;
    Spinner charSpinner;
    ImageView charImage;

    characterClass myChar = new characterClass(); // set up class to store data read in from database

    databaseClass dbCharMgr = new databaseClass(this,"disneycharacters.s3db",null,1); // set up database manager object

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.character);
        initialise();

       try
        {
            dbCharMgr.dbCreate(); // create a database
        }catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    public void initialise()
    {
        charName = (TextView) findViewById(R.id.charName);
        charDescription = (TextView) findViewById(R.id.charDescription);
        charSpinner = (Spinner)findViewById(R.id.spinner);
        charImage = (ImageView)findViewById((R.id.mickey));

        charSpinner.setOnItemSelectedListener(this);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View arg1, int pos, long arg3)
    {
        // when an item is selected get that items text and store it in a string
        String text = parent.getSelectedItem().toString();

        // call find character method in order to retrieve appropriate record from database passing in data from the spinner.
        // this data then gets stored in the character object myChar
        myChar = dbCharMgr.findCharacter(text);

        // set textfields to data taken from database
        charName.setText(myChar.getCharName());
        charDescription.setText(myChar.getCharDescription());

        // set up image path details in order to display the correct picture for the character
        String sImagePath = "drawable/" + myChar.getImageName();
        Context appContext = getApplicationContext();
        int imgResID = appContext.getResources().getIdentifier(sImagePath,"drawable","com.example.james.mobilecoursework");
        charImage.setImageResource(imgResID);
    }

    public void onNothingSelected(AdapterView parent)
    {
        // Do nothing.
    }
}
